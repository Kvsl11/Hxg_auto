"""Rebinding the package attribute after importing the module."""
from .submodule import submodule
